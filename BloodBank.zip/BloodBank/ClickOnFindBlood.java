package basicPrograms;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class ClickOnFindBlood 
{

	public static void main(String[] args) throws Exception
	{
		Select s;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe\\");
		WebDriver driver=new ChromeDriver();
		String name;
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//Blood Group
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_cboBlood-button")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.id("ui-id-5")).click();
		Thread.sleep(2000);
		
		//Select State
		s=new Select(driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_cboState\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Andhra Pradesh");
		Thread.sleep(2000);

		//Select District
		s=new Select(driver.findElement(By.xpath("//*[@name=\"ctl00$ContentPlaceHolder1$cboCity\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Visakhapatnam");
		Thread.sleep(2000);
		
		//Select Tehsil
		s=new Select(driver.findElement(By.xpath("//*[@name=\"ctl00$ContentPlaceHolder1$cboTeh\"]")));
		Thread.sleep(2000);
		s.selectByVisibleText("Visakhapatnam (Urban)");
		Thread.sleep(2000);
		
		//Click Find Blood
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSave")).click();
		
		
		// take a screen shot:
	    
	       File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	     Files.copy(f, new File("C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\findblood.jpg"));
		
	
		
	}

}
