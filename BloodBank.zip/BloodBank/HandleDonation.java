package basicPrograms;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class HandleDonation 
{
	public static void main(String[] args) throws Exception
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe\\");
		WebDriver driver=new ChromeDriver();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		//Maximize Browser
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//Click on Donations
		driver.findElement(By.linkText("DONATE US")).click();
		Thread.sleep(3000);
		
		//Click on other Amount
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtAmount")).sendKeys("300");	
		Thread.sleep(3000);
		
		//Details:
		//Full Name:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtName")).sendKeys("Bhaskar");
		Thread.sleep(2000);	
		
		//Email Id:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtEmail")).sendKeys("meda.bhaskar365@gmail.com");
		Thread.sleep(2000);	
		
		//Mobile No:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtMobile")).sendKeys("9052422213");
		Thread.sleep(2000);	
		
		//Country:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtCountry")).sendKeys("India");
		Thread.sleep(2000);	
		
		//State:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtState")).sendKeys("AndhraPradesh");
		Thread.sleep(2000);	
		
		//City:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtCity")).sendKeys("Visakhapatnam");
		Thread.sleep(2000);	
		
		//Pin code:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtPinCode")).sendKeys("530017");
		Thread.sleep(2000);	
		
		//Address:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtAddress")).sendKeys("Peddawaltair");
		Thread.sleep(2000);	
		
		//Click Donate now:
		driver.findElement(By.name("ctl00$ContentPlaceHolder1$btnSave")).click();
		Thread.sleep(3000);
	
		//Screenshot:
		File s=	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(s, new File("C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\donate us.jpg"));
		

		
	}

}
