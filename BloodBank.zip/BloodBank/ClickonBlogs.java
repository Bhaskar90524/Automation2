package basicPrograms;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class ClickonBlogs 
{

	public static void main(String[] args) throws Exception
	{
		
		Select s;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe\\");
		WebDriver driver=new ChromeDriver();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
				
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//Click on Blogs
		driver.findElement(By.linkText("BLOGS")).click();
		Thread.sleep(2000);
		
		//Click on Read More
		driver.findElement(By.xpath("//a[@class='education']")).click();
		Thread.sleep(3000);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		Thread.sleep(2000);
		
		//Scroll down
		js.executeScript("window.scrollBy(0,700)");
        Thread.sleep(2000);
        
        //Scroll Up
		js.executeScript("window.scrollTo(0, 0)");
		Thread.sleep(2000);

		//Take output Screenshot
		
		File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    Files.copy(f, new File("C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\ClickOnBlogs.jpg"));
	
		}
}