/**
 * 
 */
/**
 * @author medab
 *
 */
module BloodBank {
}