package basicPrograms;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class bloodBank_createPage {

	public static void main(String[] args) throws Exception
	{
		{
			Select s;
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe\\");
			WebDriver driver=new ChromeDriver();
			String name;
			
			//URL
			driver.get("https://bloodbanktoday.com/user/CreatePage");
			Thread.sleep(2000);
			
			driver.manage().window().maximize();
			Thread.sleep(2000);
			
			//Email or Mobile No:
			driver.findElement(By.name("txtLoginUserName")).sendKeys("9052422213");
			Thread.sleep(2000);	
			
			//Password:
			driver.findElement(By.name("txtLoginPassword")).sendKeys("Bhasu@365");
			Thread.sleep(2000);	
			
			//Sign In:
			driver.findElement(By.name("btnSave")).click();
			Thread.sleep(2000);	
			
			//Create Page:
			driver.findElement(By.xpath("//*[@id=\"main-menu-inner\"]/ul/li[6]/a")).click();
			Thread.sleep(3000);	
			
			 //Add My Page:
			driver.findElement(By.id("ctl00_ContentPlaceHolder1_addDataLink")).click();
			Thread.sleep(3000);	
			
			
			//Name:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtPageName")).sendKeys("Bhaskar");
			Thread.sleep(2000);	
			
			//Mobile No:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtMobileNo")).sendKeys("9052422213");
			Thread.sleep(2000);	
			
			//Contact No:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtContact")).sendKeys("2876578");
			Thread.sleep(2000);
			
			//Email ID:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtEmailId")).sendKeys("meda.bhaskarrao@gmail.com");
			Thread.sleep(2000);
			
			//Fax:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtFax")).sendKeys("2456789");
			Thread.sleep(2000);
			
			//State:
			s=new Select(driver.findElement(By.xpath("//select[@name='ctl00$ContentPlaceHolder1$cboState']")));
			s.selectByValue("5");
			Thread.sleep(2000);
			
			//District:
			s=new Select(driver.findElement(By.xpath("//select[@name='ctl00$ContentPlaceHolder1$cboCity']")));
			s.selectByVisibleText("Visakhapatnam");
			Thread.sleep(2000);
			
			//Pin code:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtPinCode")).sendKeys("530017");
			Thread.sleep(2000);
			
			//Address:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtAddress")).sendKeys("Dr.no:1-19-10, Plot.no - 40");
			Thread.sleep(2000);
			
			//About:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtAbout")).sendKeys("Blood Donation");
			Thread.sleep(2000);
			
			//Story:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$txtStory")).sendKeys("I am a working professional and I am interested to donate blood who are in need");
			Thread.sleep(2000);
			
			//Page Type:
			s=new Select(driver.findElement(By.xpath("//select[@name='ctl00$ContentPlaceHolder1$cboPageType']")));
			s.selectByVisibleText("BloodBank");
			Thread.sleep(2000);
			
			//Page Object:
			s=new Select(driver.findElement(By.xpath("//select[@name='ctl00$ContentPlaceHolder1$cboPageCategory']")));
			s.selectByVisibleText("Private");
			Thread.sleep(2000);
			
			//Choose File:
			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_FileUpload_images\"]"));
			Thread.sleep(2000);
			String filePath = "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\ClickOnBlogs.jpg";
			Thread.sleep(2000);
	        fileInput.sendKeys(filePath);
	        Thread.sleep(2000);
	        
	        //Save:
			driver.findElement(By.name("ctl00$ContentPlaceHolder1$btnSave")).click();
			Thread.sleep(2000);
	
		}
	}
}

	
	
