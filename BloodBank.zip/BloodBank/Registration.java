package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration 
{
	public static void main(String[] args) throws Exception
	{
		Select s;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe\\");
		WebDriver driver=new ChromeDriver();
		String name;
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//Registration Button
		driver.findElement(By.linkText("REGISTER")).click();
		Thread.sleep(2000);
		
		//First Name:
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtName")).sendKeys("Bhaskar");
		Thread.sleep(2000);
		
		//Email:
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEmail")).sendKeys("bhaskar365@gmail.com");
		Thread.sleep(2000);
		
		//Mobile No:
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtMobile")).sendKeys("9052422213");
		Thread.sleep(2000);
		
		//Create Password:
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtLoginPassword")).sendKeys("12345");
		Thread.sleep(2000);
		
		///BloodGroup
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_cboBloodGroup-button")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("ui-id-6")).click();
		Thread.sleep(3000);

		
		//Gender:
		driver.findElement(By.xpath("//span[@id=\"ctl00_ContentPlaceHolder1_cboGender-button\"]")).click();
		driver.findElement(By.xpath("//div[@id=\"ui-id-10\"]")).click();
		Thread.sleep(2000);

		//Birth Date:
		s= new Select(driver.findElement(By.name("/ctl00$ContentPlaceHolder1$cboDobDay")));
		Thread.sleep(2000);
		s.selectByIndex(12);
		Thread.sleep(2000);
		
		//BirthMonth 
		s=new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboDobMonth\"]")));
		s.selectByIndex(3); 
		Thread.sleep(2000);
		
		//BirthYear  
		s=new Select(driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboDobYear\"]")));
		s.selectByIndex(5); 
		Thread.sleep(2000);

		//Weight 
		driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtWeight")).sendKeys("66"); 
		Thread.sleep(2000);
		
		//last donation date
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboLastDay\"]"))));
		s.selectByIndex(6); Thread.sleep(2000);

		//last donation month
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboLastMonth\"]"))));
		s.selectByIndex(9); 
	    Thread.sleep(2000);

        //Donation Date >> Year 
	    s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboLastYear\"]"))));
	    s.selectByIndex(2);
	    Thread.sleep(2000);
		
	    //PinCode
	    driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtPinCode")).sendKeys("530017");
	    Thread.sleep(2000);
		
	    //Select State 
	    s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboState\"]"))));
	    s.selectByVisibleText("Andhra Pradesh");
	    Thread.sleep(2000);

	    //Select District 
	    s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboCity\"]"))));
	    s.selectByVisibleText("Visakhapatnam");
	    Thread.sleep(2000);
		
	    //Select Tehsil 
	    s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboTeh\"]"))));
 		s.selectByVisibleText("Visakhapatnam (Urban)");
	  	Thread.sleep(2000);
	  	
	  	//Enter City or Village  
	  	driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAddress")).sendKeys("viskhapathanam");
	  	Thread.sleep(2000);
	  		
	  	//Accept terms & conditions	
	  	driver.findElement(By.xpath("//input[@id='ctl00_ContentPlaceHolder1_chkTerms']")).click();
	  	Thread.sleep(2000);
	  	
	  	
	  	//Submit Button
	  	driver.findElement(By.xpath("//input[@type='submit']")).click();
	  	
	}
	  }

		
		
		
	
